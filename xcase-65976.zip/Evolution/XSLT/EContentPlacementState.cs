﻿namespace XCase.Evolution
{
    internal enum EContentPlacementState
    {
        Added,
        Moved,  
        AsItWas
    }
}