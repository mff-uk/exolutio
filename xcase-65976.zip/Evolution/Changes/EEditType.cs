﻿namespace XCase.Evolution
{
    public enum EEditType
    {
        Addition, 
        Migratory, 
        Sedentary,
        Removal
    }
}