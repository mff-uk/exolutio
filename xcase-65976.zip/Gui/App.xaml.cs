//#define consoletest

using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;
using XCase.Gui.MainMenuCommands;
using XCase.Model;
using XCase.View.Controls;

namespace XCase.Gui
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : System.Windows.Application
    {
		
    }
}