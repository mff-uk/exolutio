using System;
using System.Collections.Generic;
using System.Text;

namespace XCase.Gui
{
	/// <summary>
	/// Collection of <see cref="RecentFile"/>s.
	/// </summary>
    class RecentFiles : System.Collections.ObjectModel.ObservableCollection<RecentFile>
    {

        public RecentFiles()
        {
        }

    }
}
