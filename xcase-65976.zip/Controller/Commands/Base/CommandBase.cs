﻿using System;
using System.Collections.Generic;
using XCase.Controller.Dialogs;
using XCase.Model;

namespace XCase.Controller.Commands
{
	/// <summary>
    /// Abstract command, all other Commands have to inherit from this base class. Prescribes 
    /// command infrastructure, handles command stacks. Execution does not automatically put the command on the 
    /// "Undo"/"Redo" stack. Consider using <see cref="StackedCommandBase{ControllerType}"/> if this is desirable.
    /// </summary>
	/// <remarks>
	/// Inheriting classes have to implement <see cref="CommandOperation"/> and <see cref="UndoOperation"/> and 
	/// and <see cref="CanExecute"/> methods. <see cref="OnCanExecuteChanged"/> should be called each time some
	/// changes occur that affect whether or not the command should execute.
	/// </remarks>
	/// <seealso cref="StackedCommandBase{ControllerType}"/>
    public abstract class CommandBase
	{
		/// <summary>
		/// Description of the command (is shown to the user)
		/// </summary>
		public string Description { get; set; }

    	private static int commandCounter = 1;

		/// <summary>
		/// Returns next command number and increses the counter. 
		/// The counter is shared among all commands. 
		/// </summary>
		/// <returns></returns>
		protected static int getNextCommandNumber()
		{
			return commandCounter++;
		}

    	private int ? commandNumber = null;

		/// <summary>
		/// Number of the command. 
		/// </summary>
		/// <seealso cref="getNextCommandNumber"/>
    	public int ? CommandNumber
    	{
    		get
    		{
    			return commandNumber;
    		}
    		protected set
    		{
				if (commandNumber != null)
				{
					throw new InvalidOperationException(CommandError.CMDERR_COMMAND_NUMBER_ALTERED);
				}
    			commandNumber = value;
    		}
    	}

		protected readonly List<Element> associatedElements = new List<Element>();
		
		/// <summary>
		/// Elements associated with the command. 
		/// </summary>
		public virtual IList<Element> AssociatedElements
		{
			get { return associatedElements; }
		}

        /// <summary>
        /// Indicates whether the command should or should not be put to the Undo stack
        /// </summary>
        protected bool Undoable = true;

		/// <summary>
		/// Possible operation results
		/// </summary>
    	public enum OperationResult
        {
			/// <summary>
			/// Operation completed successfully
			/// </summary>
            OK,
			/// <summary>
			/// Operation failed
			/// </summary>
            Failed
        }
        
		/// <summary>
		/// This event should be raised each some condition that determines whether 
		/// the command can execute or not changes
		/// </summary>
        public virtual event EventHandler CanExecuteChanged;

		/// <summary>
		/// Holds description of the error that caused <see cref="CanExecute"/> to fail. 
		/// Should be set in <see cref="CanExecute"/>.
		/// </summary>
		public string ErrorDescription { get; protected set; }

        /// <summary>
        /// Returns true if command can be executed.
        /// </summary>
        /// <returns>True if command can be executed</returns>
        public abstract bool CanExecute();

        /// <summary>
        /// This method should be called each time some
        /// changes occur that affect whether or not the command should execute.
        /// </summary>
        /// <param name="sender">subscribers of the <see cref="CanExecuteChanged"/> event will get this value in the sender argument</param>
        /// <param name="args">subscribers of the <see cref="CanExecuteChanged"/> event will get this value in the args argument</param>
        public virtual void OnCanExecuteChanged(object sender, EventArgs args)
        {
            if (CanExecuteChanged != null)
            {
                CanExecuteChanged(sender, args);
            }
        }

		private static CommandFieldsChecker fieldsChecker;
		
		/// <summary>
		/// Returns <see cref="CommandFieldsChecker"/> instance. Can be used to check 
		/// mandatory arguments and command results. 
		/// </summary>
		/// <seealso cref="MandatoryArgumentAttribute"/>
		/// <seealso cref="CommandResultAttribute"/>
		protected static CommandFieldsChecker FieldsChecker
		{
			get
			{
				if (fieldsChecker == null)
				{
					fieldsChecker = new CommandFieldsChecker();
				}
				return fieldsChecker;
			}
		}

        /// <summary>
        /// Executive function of a command
        /// </summary>
        /// <seealso cref="UndoOperation"/>
        internal abstract void CommandOperation();

        /// <summary>
        /// Undo executive function of a command. Should revert the <see cref="CommandOperation"/> executive 
        /// function and return the state to the state before CommandOperation was execute.
        /// <returns>returns <see cref="OperationResult.OK"/> if operation succeeded, <see cref="OperationResult.Failed"/> otherwise</returns>
        /// </summary>
        /// <remarks>
        /// <para>If  <see cref="OperationResult.Failed"/> is returned, whole undo stack is invalidated</para>
        /// </remarks>
        internal abstract OperationResult UndoOperation();

        /// <summary>
        /// Redo executive function of a command. Should revert the <see cref="UndoOperation"/>.
        /// Usually, this is the same as <see cref="CommandOperation"/>
        /// but commands adding new elements to model need to redefine this method to avoid
        /// creation of a completely new instance
        /// </summary>
        internal virtual void RedoOperation()
        {
            CommandOperation();
        }
        ///<summary>
        ///Defines the method to be called when the command is invoked.
        ///</summary>
		public virtual void Execute()
		{
			CommandNumber = getNextCommandNumber();
			// check mandatory arguments
			#if DEBUG 
			FieldsChecker.CheckMandatoryArguments(this);
			#endif
			if (CommandCantExecuteDialog.CheckCanExecute(this))
			{
				CommandOperation();
			}
			#if DEBUG
			FieldsChecker.CheckCommandResults(this);
			#endif
		}

        /// <summary>
        /// Defines method to be called when the command rollback/undo is invoked
        /// </summary>
        public virtual void UnExecute()
        {
            UndoOperation();
        }

		/// <summary>
		/// Returns a <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.     
		/// </summary>
		/// <returns>
		/// A <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.      
		/// </returns>
		public override string ToString()
		{
			return this.GetType().Name;
		}
	}
}
